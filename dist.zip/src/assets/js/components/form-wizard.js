/*
Template Name: Lahomes - Real Estate Admin Dashboard Template
Author: Techzaa
File: wizard Js File
*/

new Wizard('#horizontalwizard');

new Wizard('#verticalwizard');